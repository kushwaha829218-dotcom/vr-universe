import { useEffect } from 'react'
import { Route, Routes, useLocation } from 'react-router-dom'
import Navbar from './components/Navbar'
import Footer from './components/Footer'
import AuthForm from './components/AuthForm'
import Home from './pages/Home'
import Department from './pages/Department'
import { About, NotFound, Placeholder } from './pages/Info'
import { departments } from './data/departments'
export default function App() {
 const { pathname }=useLocation()
 useEffect(()=>window.scrollTo(0,0),[pathname])
 const auth=(m:'login'|'signup')=><section className="min-h-screen flex items-center justify-center px-4 pt-24 pb-10"><AuthForm mode={m}/></section>
 return (<><div className="stars"/><Navbar/>
  <main key={pathname} className="page min-h-[70vh]"><Routes>
   <Route path="/" element={<Home/>}/>
   {departments.map(d=><Route key={d.slug} path={d.path} element={<Department/>}/>)}
   <Route path="/about" element={<About/>}/><Route path="/login" element={auth('login')}/><Route path="/signup" element={auth('signup')}/>
   <Route path="/privacy" element={<Placeholder title="Privacy Policy"/>}/><Route path="/terms" element={<Placeholder title="Terms"/>}/>
   <Route path="/forgot-password" element={<Placeholder title="Forgot password"/>}/><Route path="*" element={<NotFound/>}/></Routes></main><Footer/></>)
}
