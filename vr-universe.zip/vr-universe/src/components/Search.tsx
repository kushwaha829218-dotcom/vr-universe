import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { Search as Icon, X } from 'lucide-react'
import { departments } from '../data/departments'
export default function Search() {
 const [q,setQ]=useState(''); const term=q.trim().toLowerCase()
 const results=useMemo(()=>term?departments.filter(d=>`${d.name} ${d.blurb} ${d.keywords}`.toLowerCase().includes(term)):[],[term])
 return (<div className="mx-auto max-w-2xl" role="search"><div className="relative">
  <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-mute" size={20}/>
  <input className="input !rounded-full !pl-12 !pr-12 !py-4" type="search" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search departments, e.g. learning, tools, dashboard" aria-label="Search VR Universe departments"/>
  {q&&<button onClick={()=>setQ('')} aria-label="Clear search" className="absolute right-3 top-1/2 -translate-y-1/2 p-2 text-mute hover:text-ink"><X size={18}/></button>}</div>
  <div className="mt-4" aria-live="polite">
   {!term&&<div className="flex flex-wrap justify-center gap-2">{departments.map(d=><Link key={d.slug} to={d.path} className="rounded-full border border-white/10 px-4 py-2 text-sm text-mute hover:text-ink hover:border-sky/60 transition">{d.name}</Link>)}</div>}
   {term&&results.length===0&&<p className="text-center text-mute">No department matches “{q}”. Try “learning”, “tools” or “dashboard”.</p>}
   {results.length>0&&<ul className="glass divide-y divide-white/5 overflow-hidden">{results.map(d=><li key={d.slug}><Link to={d.path} className="flex items-center gap-3 p-4 hover:bg-white/5"><d.icon size={20} style={{color:d.c1}}/><span><span className="font-medium">{d.name}</span><span className="block text-sm text-mute">{d.blurb}</span></span></Link></li>)}</ul>}
  </div></div>)
}
