import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { Eye, EyeOff } from 'lucide-react'
export default function AuthForm({ mode }:{ mode:'login'|'signup' }) {
 const signup=mode==='signup'
 const [show,setShow]=useState(false); const [errs,setErrs]=useState<Record<string,string>>({}); const [done,setDone]=useState(false)
 const submit=(e:FormEvent<HTMLFormElement>)=>{ e.preventDefault(); const f=new FormData(e.currentTarget); const g=(k:string)=>String(f.get(k)||'').trim(); const x:Record<string,string>={}
  if(signup&&g('name').length<2) x.name='Enter your full name.'
  if(!/^\S+@\S+\.\S+$/.test(g('email'))) x.email='Enter a valid email address.'
  if(g('password').length<8) x.password='Use at least 8 characters.'
  if(signup&&g('confirm')!==g('password')) x.confirm='Passwords do not match.'
  if(signup&&!f.get('terms')) x.terms='Accept the terms to continue.'
  setErrs(x); setDone(Object.keys(x).length===0) }
 const field=(n:string,label:string,type='text',auto?:string)=>(<div><label htmlFor={n} className="text-sm text-mute">{label}</label>
  <div className="relative mt-1"><input id={n} name={n} type={type==='password'&&show&&n==='password'?'text':type} autoComplete={auto} className="input" aria-invalid={!!errs[n]}/>
  {n==='password'&&<button type="button" onClick={()=>setShow(!show)} aria-label={show?'Hide password':'Show password'} className="absolute right-3 top-1/2 -translate-y-1/2 text-mute hover:text-ink">{show?<EyeOff size={18}/>:<Eye size={18}/>}</button>}</div>
  {errs[n]&&<p role="alert" className="mt-1 text-sm text-red-300">{errs[n]}</p>}</div>)
 return (<form onSubmit={submit} noValidate className="glass p-6 sm:p-8 w-full max-w-md space-y-4">
  <h1 className="text-3xl font-bold">{signup?'Create your account':'Welcome back'}</h1>
  <p className="text-sm text-mute">Phase 1 preview: forms are validated in your browser only. Accounts are not connected yet, so nothing is sent or saved.</p>
  {signup&&field('name','Full name','text','name')}
  {field('email','Email','email','email')}
  {field('password','Password','password',signup?'new-password':'current-password')}
  {signup&&field('confirm','Confirm password','password','new-password')}
  {signup&&<div><label className="flex items-start gap-3 text-sm text-mute"><input type="checkbox" name="terms" className="mt-1 accent-sky h-4 w-4"/>I accept the <Link to="/terms" className="text-sky underline">Terms</Link> and <Link to="/privacy" className="text-sky underline">Privacy Policy</Link>.</label>{errs.terms&&<p role="alert" className="mt-1 text-sm text-red-300">{errs.terms}</p>}</div>}
  {!signup&&<Link to="/forgot-password" className="block text-sm text-sky">Forgot password?</Link>}
  <button className="btn-primary w-full">{signup?'Create account':'Sign in'}</button>
  {done&&<p role="status" className="text-sm text-sky">Details look valid. Real {signup?'registration':'sign-in'} will work once a backend is connected.</p>}
  <p className="text-sm text-mute text-center">{signup?<>Already registered? <Link to="/login" className="text-sky">Sign in</Link></>:<>New here? <Link to="/signup" className="text-sky">Create an account</Link></>}</p></form>)
}
