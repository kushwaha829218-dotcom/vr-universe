import { Link } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'
import Planet from './Planet'
import type { Department } from '../data/departments'
export default function DepartmentCard({ d }:{ d:Department }) {
 const Icon=d.icon
 return (<Link to={d.path} className="glass group relative overflow-hidden p-6 block transition duration-300 hover:-translate-y-1 hover:border-sky/50">
  <Planet c1={d.c1} c2={d.c2} size={120} className="absolute -right-8 -top-8 opacity-40 group-hover:opacity-70 transition"/>
  <div className="relative"><span className="inline-flex h-11 w-11 items-center justify-center rounded-xl bg-white/10"><Icon size={22} style={{color:d.c1}}/></span>
   <h3 className="mt-5 text-xl font-semibold">{d.name}</h3><p className="mt-2 text-mute text-sm leading-relaxed">{d.blurb}</p>
   <span className="mt-5 inline-flex items-center gap-1.5 text-sm text-sky">Open department <ArrowRight size={16} className="transition group-hover:translate-x-1"/></span></div></Link>)
}
