import { useEffect, useState } from 'react'
import { Link, NavLink, useLocation } from 'react-router-dom'
import { Menu, X } from 'lucide-react'
import Logo from './Logo'
const links = [['Home','/'],['Explore','/explore'],['AI','/ai'],['Tools','/tools'],['Academy','/academy'],['About','/about']] as const
export default function Navbar() {
 const [open,setOpen]=useState(false); const { pathname }=useLocation()
 useEffect(()=>setOpen(false),[pathname])
 const cls=({isActive}:{isActive:boolean})=>`px-3 py-2 text-sm rounded-full transition ${isActive?'text-sky':'text-mute hover:text-ink'}`
 return (<header className="fixed top-0 inset-x-0 z-50 bg-space/70 backdrop-blur-lg border-b border-white/10">
  <div className="mx-auto max-w-7xl h-16 px-4 sm:px-6 flex items-center justify-between">
   <Logo compact/>
   <nav aria-label="Primary" className="hidden lg:flex items-center gap-1">{links.map(([l,p])=><NavLink key={p} to={p} end={p==='/'} className={cls}>{l}</NavLink>)}</nav>
   <div className="hidden lg:flex items-center gap-2"><Link to="/login" className="btn-ghost !py-2">Login</Link><Link to="/signup" className="btn-primary !py-2">Create Account</Link></div>
   <button className="lg:hidden p-2 rounded-lg min-h-[44px] min-w-[44px] flex items-center justify-center" aria-label={open?'Close menu':'Open menu'} aria-expanded={open} onClick={()=>setOpen(!open)}>{open?<X/>:<Menu/>}</button>
  </div>
  {open&&<div className="lg:hidden bg-deep/95 border-t border-white/10 px-4 pb-5 pt-2 flex flex-col">
   {links.map(([l,p])=><NavLink key={p} to={p} end={p==='/'} className={({isActive})=>`py-3 text-lg border-b border-white/5 ${isActive?'text-sky':'text-ink'}`}>{l}</NavLink>)}
   <div className="grid grid-cols-2 gap-3 mt-4"><Link to="/login" className="btn-ghost">Login</Link><Link to="/signup" className="btn-primary">Create Account</Link></div></div>}
 </header>)
}
