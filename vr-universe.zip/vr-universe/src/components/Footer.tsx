import { Link } from 'react-router-dom'
import Logo from './Logo'
import { departments } from '../data/departments'
export default function Footer() {
 return (<footer className="border-t border-white/10 bg-space/80 mt-24"><div className="mx-auto max-w-7xl px-4 sm:px-6 py-12 grid gap-10 md:grid-cols-4">
  <div className="md:col-span-2"><Logo/><p className="mt-4 text-mute max-w-sm">EXPLORE BEYOND LIMITS.</p></div>
  <div><h3 className="font-semibold mb-3">Platform</h3><ul className="space-y-2 text-mute">
   {[['Home','/'],['About','/about'],['Login','/login'],['Create Account','/signup']].map(([l,p])=><li key={p}><Link className="hover:text-sky" to={p}>{l}</Link></li>)}
   <li><Link className="hover:text-sky" to="/privacy">Privacy Policy</Link></li><li><Link className="hover:text-sky" to="/terms">Terms</Link></li></ul></div>
  <div><h3 className="font-semibold mb-3">Departments</h3><ul className="space-y-2 text-mute">{departments.map(d=><li key={d.slug}><Link className="hover:text-sky" to={d.path}>{d.name}</Link></li>)}</ul></div>
 </div><p className="border-t border-white/10 py-6 text-center text-sm text-mute">© {new Date().getFullYear()} VR UNIVERSE. All rights reserved.</p></footer>)
}
