export default function Planet({ c1, c2, size, ring=false, className='' }:{ c1:string; c2:string; size:number|string; ring?:boolean; className?:string }) {
 return <div aria-hidden="true" className={`planet ${ring?'ring':''} ${className}`} style={{ ['--c1' as string]:c1, ['--c2' as string]:c2, width:size, height:size }}/>
}
