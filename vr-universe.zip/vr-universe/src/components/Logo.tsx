import { Link } from 'react-router-dom'
export default function Logo({ compact=false }:{ compact?:boolean }) {
 return (<Link to="/" aria-label="VR UNIVERSE home" className="flex items-center gap-2.5">
  <svg width="32" height="32" viewBox="0 0 32 32" aria-hidden="true"><defs><linearGradient id="lg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#38BDF8"/><stop offset="1" stopColor="#A78BFA"/></linearGradient></defs>
   <circle cx="16" cy="16" r="7" fill="url(#lg)"/><ellipse cx="16" cy="16" rx="14" ry="5" fill="none" stroke="#F8FAFC" strokeOpacity=".6" transform="rotate(-20 16 16)"/></svg>
  <span className={`font-bold tracking-[0.18em] ${compact?'text-sm':'text-base'}`}>VR UNIVERSE</span></Link>)
}
