import { Link } from 'react-router-dom'
export function About() {
 return (<section className="mx-auto max-w-3xl px-4 sm:px-6 pt-32"><h1 className="text-4xl sm:text-5xl font-bold">About VR UNIVERSE</h1><p className="mt-2 text-sky">EXPLORE BEYOND LIMITS.</p>
  <div className="mt-8 space-y-5 text-mute text-lg"><p>VR UNIVERSE is a unified digital ecosystem combining AI, productivity, education, creativity and personal digital experiences.</p><p>It is built for global public users and individual personal users who want one dependable place for the digital things they do.</p><p>This is Phase 1: the interface and navigation. AI, community and account features are not operational yet and are labelled that way throughout.</p></div>
  <Link to="/" className="btn-primary mt-8">Explore the universe</Link></section>)
}
export function Placeholder({ title }:{ title:string }) {
 return (<section className="mx-auto max-w-3xl px-4 sm:px-6 pt-32"><h1 className="text-4xl font-bold">{title}</h1><p className="mt-4 text-mute">This page is a placeholder. The final text will be added before launch.</p><Link to="/" className="btn-ghost mt-6">Back to home</Link></section>)
}
export function NotFound() {
 return (<section className="mx-auto max-w-3xl px-4 pt-40 text-center"><h1 className="text-5xl font-bold">Lost in space</h1><p className="mt-4 text-mute">That page does not exist.</p><Link to="/" className="btn-primary mt-6">Return home</Link></section>)
}
