import { Link } from 'react-router-dom'
import { ArrowRight, Layers, ShieldCheck, Smartphone, Sparkles } from 'lucide-react'
import Planet from '../components/Planet'
import Search from '../components/Search'
import DepartmentCard from '../components/DepartmentCard'
import { departments } from '../data/departments'
const why=[[Layers,'One ecosystem','AI, tools, learning and creative work under one roof.'],[ShieldCheck,'Honest by design','Every unfinished area is clearly labelled.'],[Smartphone,'Built for any screen','Mobile-first layouts from phones to wide monitors.'],[Sparkles,'Light and smooth','Pure CSS motion that respects reduced-motion settings.']] as const
export default function Home() {
 return (<>
  <section className="relative min-h-[100svh] flex items-center overflow-hidden pt-24 pb-16"><div className="mx-auto max-w-7xl px-4 sm:px-6 grid lg:grid-cols-2 gap-10 items-center w-full">
   <div className="relative z-10"><span className="inline-block rounded-full border border-sky/40 bg-sky/10 px-4 py-1.5 text-xs tracking-widest text-sky">THE NEXT DIGITAL EXPERIENCE</span>
    <h1 className="mt-6 text-5xl sm:text-6xl xl:text-7xl font-bold leading-[1.02]">EXPLORE <br/>BEYOND <br/>LIMITS.</h1>
    <p className="mt-6 max-w-lg text-lg text-mute">VR UNIVERSE is a unified digital ecosystem that brings AI, productivity, education, creativity and personal experiences together in one place.</p>
    <div className="mt-8 flex flex-wrap gap-3"><a href="#explore" className="btn-primary">EXPLORE UNIVERSE <ArrowRight size={16}/></a><Link to="/about" className="btn-ghost">DISCOVER MORE</Link></div></div>
   <div className="relative h-[320px] sm:h-[460px] flex items-center justify-center" aria-hidden="true">
    <div className="absolute inset-0 m-auto h-3/4 w-3/4 rounded-full bg-nebula/20 blur-3xl"/>
    <Planet c1="#38BDF8" c2="#5b21b6" size="min(70vw,380px)" ring/>
    <Planet c1="#A78BFA" c2="#1e1b4b" size={64} className="absolute right-[6%] top-[8%]"/><Planet c1="#67e8f9" c2="#0c4a6e" size={36} className="absolute left-[8%] bottom-[10%]"/></div></div></section>
  <div className="px-4 sm:px-6 -mt-4"><Search/></div>
  <section id="explore" className="mx-auto max-w-7xl px-4 sm:px-6 pt-24 scroll-mt-20"><h2 className="text-3xl sm:text-4xl font-bold">Explore the universe</h2><p className="mt-3 text-mute max-w-xl">Eight departments, one ecosystem. Open any to see what it is and where it stands.</p>
   <div className="mt-10 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{departments.map(d=><DepartmentCard key={d.slug} d={d}/>)}</div></section>
  <section className="mx-auto max-w-7xl px-4 sm:px-6 pt-24 grid gap-5 lg:grid-cols-3">
   <div className="glass p-6 lg:col-span-2"><h2 className="text-2xl font-bold">Featured tools</h2><p className="mt-2 text-mute text-sm">Planned for VR Tools. None are live yet.</p>
    <ul className="mt-5 grid sm:grid-cols-3 gap-3">{['Text utilities','Planners','Converters'].map(t=><li key={t} className="rounded-xl bg-white/5 p-4"><p className="font-medium">{t}</p><p className="text-xs text-nebula mt-1">Planned</p></li>)}</ul>
    <Link to="/tools" className="btn-ghost mt-5">View VR Tools</Link></div>
   <div className="glass p-6"><h2 className="text-2xl font-bold">Latest updates</h2><ul className="mt-4 space-y-3 text-sm"><li><p className="font-medium">Phase 1 frontend</p><p className="text-mute">Homepage, department pages, search, login and signup interfaces.</p></li><li><p className="font-medium">Next: backend</p><p className="text-mute">Accounts and AI are not connected yet.</p></li></ul></div></section>
  <section className="mx-auto max-w-7xl px-4 sm:px-6 pt-24"><h2 className="text-3xl font-bold">Why VR Universe</h2>
   <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">{why.map(([I,t,s])=><div key={t} className="glass p-6"><I className="text-sky" size={24}/><h3 className="mt-4 font-semibold">{t}</h3><p className="mt-1 text-sm text-mute">{s}</p></div>)}</div></section>
  <section className="mx-auto max-w-4xl px-4 sm:px-6 pt-24 text-center"><h2 className="text-3xl font-bold">About the platform</h2><p className="mt-4 text-mute">VR UNIVERSE aims to give global public users and individual personal users a single, calm place for intelligent assistance, useful tools, learning and creative work.</p><Link to="/about" className="btn-primary mt-6">Read about VR Universe</Link></section></>)
}
