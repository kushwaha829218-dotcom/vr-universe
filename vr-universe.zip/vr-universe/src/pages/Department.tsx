import { Link, useLocation } from 'react-router-dom'
import Planet from '../components/Planet'
import { departments } from '../data/departments'
export default function Department() {
 const { pathname }=useLocation(); const d=departments.find(x=>x.path===pathname)
 if(!d) return null
 const Icon=d.icon
 return (<section className="mx-auto max-w-7xl px-4 sm:px-6 pt-32 grid lg:grid-cols-2 gap-10 items-center">
  <div><span className="inline-flex items-center gap-2 rounded-full border border-nebula/40 bg-nebula/10 px-4 py-1.5 text-xs tracking-widest text-nebula">COMING SOON · NOT YET AVAILABLE</span>
   <h1 className="mt-5 flex items-center gap-3 text-4xl sm:text-6xl font-bold"><Icon style={{color:d.c1}} size={44}/>{d.name}</h1>
   <p className="mt-4 text-lg text-mute max-w-lg">{d.blurb} {d.detail}</p>
   <div className="glass mt-8 p-6 max-w-lg"><h2 className="font-semibold">Planned for this department</h2><ul className="mt-3 space-y-2 text-mute list-disc pl-5">{d.planned.map(p=><li key={p}>{p}</li>)}</ul></div>
   <div className="mt-8 flex flex-wrap gap-3"><Link to="/signup" className="btn-primary">Create Account</Link><Link to="/" className="btn-ghost">Back to the universe</Link></div></div>
  <div className="flex justify-center py-8"><Planet c1={d.c1} c2={d.c2} size="min(65vw,340px)" ring={d.slug==='academy'||d.slug==='studio'}/></div></section>)
}
