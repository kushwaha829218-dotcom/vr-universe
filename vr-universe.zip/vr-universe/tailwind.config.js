export default { content: ['./index.html','./src/**/*.{ts,tsx}'],
 theme: { extend: {
  colors: { space:'#05070D', deep:'#0B1020', card:'#111827', sky:'#38BDF8', nebula:'#A78BFA', ink:'#F8FAFC', mute:'#94A3B8' },
  fontFamily: { sans:['"Space Grotesk"','Inter','system-ui','sans-serif'] } } } }
